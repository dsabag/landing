$('#form').on("submit", function (event) {
    event.preventDefault();

    $('p.text-danger').text("");
    $('#submit').attr('disabled', true);

    var formValid = true;
    var emailRegExp = /^(?!.*\.\.)[\w.\-#!$%&'*+\/=?^_`{}|~]{1,35}@[\w.\-]+\.[a-zA-Z]{2,15}$/;
    var validPhone = /^0[2-9]\d{7,8}$/;

    var $name = $('#name'),
        $email = $('#email'),
        $phone = $('#phone'),
        $model = $('#model');

    var userInfo = {

        name: $name.val().trim(),
        email: $email.val().trim(),
        phone: $phone.val().trim(),
        model: $model.val().trim()
    };

    if (userInfo.name.length < 2 || userInfo.name.length > 70) {

        $name.next().text('* A Valid Name Is Required');
        formValid = false;

    }
    if (userInfo.email.length < 6 || !emailRegExp.test(userInfo.email)) {

        $email.next().text('* A Valid Email Is Required');
        formValid = false;
    }
    if (userInfo.phone.length < 9 || !validPhone.test(userInfo.phone)) {

        $phone.next().text('* A Valid Phone Is Required')
        formValid = false;
    }
    if (userInfo.model == "") {

        $model.next().text('* Please Select A Model')
        formValid = false;
    }

    if (formValid) {


        $.ajax({
            url: "back.php",
            type: "POST",
            dataType: "json",
            data: userInfo,
            success: function (response) {


                if (response && response.status == "success") {

                    window.location = "./tnx.html";
                }

            },
        })

    } else {
        $("#submit").attr("disabled", false);
    }

})

$(".modelSelect").on("click", function () {

    var selected = $(this).val();

    $("#model option").each(function () {
        if ($(this).text() == selected)
            $(this).attr("selected", "selected");

        $("html, body").animate({
            scrollTop: 0
        }, "slow");
    });

})