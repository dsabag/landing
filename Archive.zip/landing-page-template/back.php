<?php

header('Content-Type: application/json');

if (!empty($_POST['name']) && !empty($_POST['email'])) {

    if (!empty($_POST['phone']) && !empty($_POST['model'])) {

        $valid_phone = "/^0[2-9]\d{7,8}$/";
        $valid_model = ['huracan', 'aventador', 'urus'];

        $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
        $name = trim($name);
        $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
        $email = trim($email);
        $phone = filter_var($_POST['phone'], FILTER_SANITIZE_STRING);
        $phone = trim($phone);
        $model = filter_var($_POST['model'], FILTER_SANITIZE_STRING);
        $model = trim($model);


        if (mb_strlen($name) > 1 && mb_strlen($name) < 70) {

            if ($email) {

                if (preg_match($valid_phone, $phone)) {

                    if (in_array($model, $valid_model)) {

                        $db = new PDO('mysql:host=localhost;dbname=lamborghini;charset=utf8', 'root', 'root');
                        $sql = "INSERT INTO leads VALUES(null,?,?,?,?)";
                        $save = $db->prepare($sql);
                        $save->execute([$name, $email, $phone, $model]);


                        // send email to landing page owner
                        $response = [
                            'status' => 'success',
                        ];
                        echo json_encode($response);
                    }
                }
            }
        }
    }
}
